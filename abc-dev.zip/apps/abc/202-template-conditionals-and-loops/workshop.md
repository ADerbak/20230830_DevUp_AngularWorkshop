# Workshop for this step

* Add the sample data (videoManagerData.json or
  https://api.angularbootcamp.com/videos) to the
  VideoListComponent. For now, it's okay to define this as a component
  property and assign the data directly. In future steps, we'll
  demonstrate how to retrieve this using HTTP.

* Modify the video list template to display each video's title and
  author using `*ngFor`.
