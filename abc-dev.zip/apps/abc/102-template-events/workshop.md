# Workshop for this step

Goals:

* Get comfortable catching events from elements.

-----

1. Catch one or more events triggered by user input. You can see a list
   of available events here:
   https://developer.mozilla.org/en-US/docs/Web/Events#event_listing
