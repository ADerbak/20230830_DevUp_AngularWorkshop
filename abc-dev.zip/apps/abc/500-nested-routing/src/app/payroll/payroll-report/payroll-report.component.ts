import { Component } from '@angular/core';

@Component({
  selector: 'app-payroll-report',
  templateUrl: './payroll-report.component.html',
  standalone: true
})
export class PayrollReportComponent {}
