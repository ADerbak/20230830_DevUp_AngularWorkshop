import { Component } from '@angular/core';

@Component({
  selector: 'app-help-screen',
  templateUrl: './help.component.html',
  standalone: true
})
export default class HelpScreenComponent {}
