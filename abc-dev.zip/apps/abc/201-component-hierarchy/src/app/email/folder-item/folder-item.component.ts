import { Component } from '@angular/core';

@Component({
  selector: 'app-folder-item',
  templateUrl: './folder-item.component.html',
  standalone: true
})
export class FolderItemComponent {}
