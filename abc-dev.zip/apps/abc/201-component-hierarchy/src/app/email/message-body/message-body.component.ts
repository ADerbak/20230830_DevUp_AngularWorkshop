import { Component } from '@angular/core';

@Component({
  selector: 'app-message-body',
  templateUrl: './message-body.component.html',
  standalone: true
})
export class MessageBodyComponent {}
