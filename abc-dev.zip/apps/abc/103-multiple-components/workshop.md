# Workshop for this step

* Make a new component
* Add the new component to the declarations of AppModule
* Reference the new component in the template of AppComponent

