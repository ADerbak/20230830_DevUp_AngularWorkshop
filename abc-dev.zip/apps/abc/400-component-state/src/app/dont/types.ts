export interface Task {
  task: string;
  complete: boolean;
}
